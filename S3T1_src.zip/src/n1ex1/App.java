package n1ex1;

public class App {

	public static void main(String[] args) {
		
		Undo pilaUndo = Undo.getInstance();
		pilaUndo.addAccionPilaAcciones("Nuevo documento");
		pilaUndo.addAccionPilaAcciones("A�adir linea");
		pilaUndo.addAccionPilaAcciones("Editar final linea");
		pilaUndo.addAccionPilaAcciones("Editar color linea");
		pilaUndo.addAccionPilaAcciones("A�adir cuadrado");
		pilaUndo.addAccionPilaAcciones("Editar color cuadrado");
		
		Undo pilaUndo2 = Undo.getInstance();
		
		System.out.println("--------------------");
		pilaUndo2.verPilaAcciones();
		
		System.out.println("--------------------");
		pilaUndo.delAccionPilaAcciones();
		pilaUndo.delAccionPilaAcciones();
		
		System.out.println("--------------------");
		pilaUndo2.verPilaAcciones();

	}

}
