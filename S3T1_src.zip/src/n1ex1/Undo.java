package n1ex1;

import java.util.Stack;

public class Undo {
	
	private static Undo instancia = null;
	
	private Stack<String> pilaAcciones;

	private Undo() {
		this.pilaAcciones = new Stack<>();
	}
	
	public static Undo getInstance() {
		if (instancia == null) {
			instancia = new Undo();
		}
		return instancia;
	}
	
	public void addAccionPilaAcciones(String accion) {
		pilaAcciones.push(accion);
		System.out.println("La accion: '" + accion + "' fue a�adida a la lista de Acciones.");
	}
	
	public void delAccionPilaAcciones() {
		String accion = pilaAcciones.pop();
		System.out.println("La accion: '" + accion + "' fue eliminada de la lista de Acciones.");
	}
	
	public void verPilaAcciones() {
		System.out.println("La pila de acciones contiene:");
		for ( String ele : pilaAcciones) {
			System.out.println(ele);
		}
	}

}
