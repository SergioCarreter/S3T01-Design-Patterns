package n3ex1;

public abstract class Vehiculo {
	
	// En KW
	private double potencia;

	public Vehiculo(double potencia) {
		this.potencia = potencia;
	}
	
	public double getPotencia() {
		return potencia;
	}
	public abstract void arrancar();
	public abstract void acelerar();
	public abstract void frenar();

}
