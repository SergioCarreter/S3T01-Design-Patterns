package n3ex1;

public interface Operacion {
	
	public void execute();

}
