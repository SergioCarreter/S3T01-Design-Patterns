package n3ex1;

public class Avion extends Vehiculo{

	public Avion(double potencia) {
		super(potencia);
	}

	@Override
	public void arrancar() {
		System.out.println("Arrancando el avion. Potencia: " + getPotencia() + " KW. El sistema hidraulico mueve el eje de la turbina");
	}

	@Override
	public void acelerar() {
		System.out.println("Acelerando el avion. El sistema de control incrementa la inyeccion de combustible.");
	}

	@Override
	public void frenar() {
		System.out.println("Frenando el avion. Moviendo flaps.");	
	}

}
