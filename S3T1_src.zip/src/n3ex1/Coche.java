package n3ex1;

public class Coche extends Vehiculo {

	public Coche(double potencia) {
		super(potencia);	
	}

	@Override
	public void arrancar() {
		System.out.println("Encendiendo coche. Potencia: " + getPotencia() + " KW. Motor de combustion encendido.");
	}

	@Override
	public void acelerar() {
		System.out.println("Acelerando coche. Incrementando ratio de combustible vs Aire.");
	}

	@Override
	public void frenar() {
		System.out.println("Frenando coche. Sistema hidraulico presionan las pastillas de freno en los discos");
	}

}
