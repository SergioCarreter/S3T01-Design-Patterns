package n3ex1;

public class Barco extends Vehiculo {

	public Barco(double potencia) {
		super(potencia);
	}

	@Override
	public void arrancar() {
		System.out.println("Encendiendo motor barco. Potencia: " + getPotencia() + " KW. Helice inicia movimiento");
	}

	@Override
	public void acelerar() {
		System.out.println("Acelerando barco. Subiendo revoluciones de la helice");
	}

	@Override
	public void frenar() {
		System.out.println("Frenando barco. Invirtiendo giro de la helice");
	}

}
