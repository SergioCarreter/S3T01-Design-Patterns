package n3ex1;

public class Arrancar implements Operacion {
	
	Vehiculo v;

	public Arrancar(Vehiculo v) {
		this.v = v;
	}
	
	@Override
	public void execute() {
		v.arrancar();
	}

}
