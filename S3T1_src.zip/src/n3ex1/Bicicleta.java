package n3ex1;

public class Bicicleta extends Vehiculo {

	public Bicicleta(double potencia) {
		super(potencia);
	}

	@Override
	public void arrancar() {
		System.out.println("Arrancando la bici. Potencia: " + getPotencia() + " KW. El conductor se eleva para vencer el par inicial de arranque");
	}

	@Override
	public void acelerar() {
		System.out.println("Acelerando la bici. El conductor incrementa el par sobre los pedales");
	}

	@Override
	public void frenar() {
		System.out.println("Frenando la bici. Las pastillas presionan la llanta.");
	}
}
