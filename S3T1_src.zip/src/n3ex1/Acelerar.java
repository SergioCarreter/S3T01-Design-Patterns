package n3ex1;

public class Acelerar implements Operacion {

	Vehiculo v;

	public Acelerar(Vehiculo v) {
		this.v = v;
	}
	
	@Override
	public void execute() {
		v.acelerar();
	}

}
