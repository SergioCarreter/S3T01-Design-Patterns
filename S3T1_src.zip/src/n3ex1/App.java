package n3ex1;

public class App {

	public static void main(String[] args) {

		Vehiculo bici = new Bicicleta(0.15);
		Vehiculo coche = new Coche(115);
		Vehiculo barco = new Barco(225);
		Vehiculo avion = new Avion(400);
		
		Invoker invoker = new Invoker();
		
		Operacion biciArranca = new Arrancar(bici);
		Operacion biciAcelera = new Acelerar(bici);
		Operacion barcoArranca = new Arrancar(barco);
		Operacion biciFrena = new Frenar(bici);
		Operacion avionArranca = new Arrancar(avion);
		Operacion barcoAcelera = new Acelerar(barco);
		Operacion cocheArranca = new Arrancar(coche);
		Operacion barcoFrena = new Frenar(barco);
		Operacion cocheAcelera = new Acelerar(coche);
		Operacion avionAcelera = new Acelerar(avion);
		Operacion cocheFrena = new Frenar(coche);
		Operacion avionFrena = new Frenar(avion);
		
		invoker.a�adirOperacion(biciArranca);
		invoker.a�adirOperacion(biciAcelera);
		invoker.a�adirOperacion(barcoArranca);
		invoker.a�adirOperacion(biciFrena);
		invoker.a�adirOperacion(avionArranca);
		invoker.a�adirOperacion(barcoAcelera);
		invoker.a�adirOperacion(cocheArranca);
		invoker.a�adirOperacion(barcoFrena);
		invoker.a�adirOperacion(cocheAcelera);
		invoker.a�adirOperacion(avionAcelera);
		invoker.a�adirOperacion(cocheFrena);
		invoker.a�adirOperacion(avionFrena);
		
		invoker.ejecutaOperaciones();

	}

}
