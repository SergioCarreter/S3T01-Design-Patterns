package n3ex1;

public class Frenar implements Operacion {

	Vehiculo v;

	public Frenar(Vehiculo v) {
		this.v = v;
	}
	
	@Override
	public void execute() {
		v.frenar();
	}

}
