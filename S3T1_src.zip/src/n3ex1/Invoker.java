package n3ex1;

import java.util.ArrayList;

public class Invoker {
	
	ArrayList<Operacion> operaciones;

	public Invoker() {
		operaciones= new ArrayList<>();
	}
	
	public void a�adirOperacion(Operacion op) {
		operaciones.add(op);
	}
	
	public void ejecutaOperaciones() {
		operaciones.forEach( op -> op.execute() );
		operaciones.clear();
	}

}
