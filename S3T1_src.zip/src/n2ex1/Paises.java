package n2ex1;

public enum Paises {

	SPA, FRA, UK;
}
