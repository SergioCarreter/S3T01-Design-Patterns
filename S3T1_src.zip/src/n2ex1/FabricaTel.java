package n2ex1;

public class FabricaTel implements FabricaAbs {
	
	@Override
	public Llamable getTel( Paises pais, int num ) {
		
		Llamable tel=null;
		switch(pais) {
			case SPA:
				tel = new TelSpa(num);
				break;
			case FRA:
				tel = new TelFra(num);
				break;
			case UK:
				tel = new TelUK(num);
				break;
			default:
				System.out.println("Pais no registrado");
		}
		return tel;
	}

	@Override
	public Dirigible getDir(Paises pais, String calle, int num, String ciudad, String zipCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
