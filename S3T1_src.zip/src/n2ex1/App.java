package n2ex1;

import java.util.ArrayList;

public class App {

	public static void main(String[] args) {
		
		FabricaAbs fabDir = GeneraFabrica.getFactory(ElementosAgenda.DIR);
		Dirigible dirSpa = fabDir.getDir(Paises.SPA, "Puerta de Hierro", 0, "Madrid", "28071");
		Dirigible dirFra = fabDir.getDir(Paises.FRA, "Faubourg Saint-Honor�", 55, "Paris", "75008");
		Dirigible dirUK = fabDir.getDir(Paises.UK, "Downing", 10, "London", "SW1A 2AB");
		
		FabricaAbs fabTel = GeneraFabrica.getFactory(ElementosAgenda.TEL);
		Llamable telUK = fabTel.getTel(Paises.UK, 666777888);
		Llamable telFra = fabTel.getTel(Paises.FRA, 999888777);
		Llamable telSpa = fabTel.getTel(Paises.SPA, 666888777);
		
		ArrayList<Contacto> agenda = new ArrayList<>();
		
		System.out.println( "---------------------");
		agenda.add( new Contacto("Boris Johnson", dirUK, telUK));
		System.out.println( agenda.get(0));
		agenda.get(0).llamar();
		agenda.get(0).calcularRuta();
		
		System.out.println( "---------------------");
		agenda.add( new Contacto("Emmanuel Macron", dirFra, telFra));
		System.out.println( agenda.get(1));
		agenda.get(1).llamar();
		agenda.get(1).calcularRuta();
		
		System.out.println( "---------------------");
		agenda.add( new Contacto("Pedro Sanchez", dirSpa, telSpa));
		System.out.println( agenda.get(2));
		agenda.get(2).llamar();
		agenda.get(2).calcularRuta();
		
	}

}
