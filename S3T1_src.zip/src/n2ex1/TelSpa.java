package n2ex1;

public class TelSpa implements Llamable {
	
	private static final String PREFIJO = "+34";
	private int numero;

	public TelSpa(int numero) {
		this.numero = numero;
	}
	
	@Override
	public void llamar() {
		System.out.println( "Llamando al numero: " + PREFIJO + numero);
	}

	@Override
	public String toString() {
		return "TelSpa [numero=" + PREFIJO + numero + "]";
	}
	
	

}
