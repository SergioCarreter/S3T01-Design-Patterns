package n2ex1;

public interface Llamable {
	
	public void llamar();

}
