package n2ex1;

public class TelUK implements Llamable{

	private static final String PREFIJO = "+44";
	private int numero;

	public TelUK(int numero) {
		this.numero = numero;
	}
	
	@Override
	public void llamar() {
		System.out.println( "Calling the number: " + PREFIJO + numero);
	}

	@Override
	public String toString() {
		return "TelUK [numero=" + PREFIJO + numero + "]";
	}
	
	

}
