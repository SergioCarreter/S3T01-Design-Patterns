package n2ex1;

public class Contacto {
	
	private String nombre;
	private Dirigible dir;
	private Llamable tel;

	public Contacto(String nombre, Dirigible dir, Llamable tel) {
		this.nombre = nombre;
		this.dir = dir;
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "Contacto [nombre=" + nombre + ", dir=" + dir + ", tel=" + tel + "]";
	}
	
	public void llamar() {
		tel.llamar();
	}
	
	public void calcularRuta() {
		dir.calcularRuta();
	}

}
