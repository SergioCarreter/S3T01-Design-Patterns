package n2ex1;

public class DirUK implements Dirigible{

	private String calle;
	private int num;
	private String ciudad;
	private String zipCode;

	public DirUK(String calle, int num, String ciudad, String zipCode) {
		this.calle = calle;
		this.num = num;
		this.ciudad = ciudad;
		this.zipCode = zipCode;
	}
	
	@Override
	public void calcularRuta() {
		System.out.println("Heading to the Adress:");
		System.out.println("\t" + num + ", " + calle + " Street ");
		System.out.println("	City: " + ciudad );
		System.out.println("	Zip Code: " + zipCode);
	}

	@Override
	public String toString() {
		return "DirUK [calle=" + calle + ", num=" + num + ", ciudad=" + ciudad + ", zipCode=" + zipCode + "]";
	}
	
	
}
