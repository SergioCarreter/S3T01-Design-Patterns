package n2ex1;

public interface Dirigible {
	
	public void calcularRuta();

}
