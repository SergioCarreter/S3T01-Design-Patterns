package n2ex1;

public interface FabricaAbs {
	
	public Dirigible getDir( Paises pais, String calle, int num, String ciudad, String zipCode );
	public Llamable getTel( Paises pais, int num );

}
