package n2ex1;

public class DirFra implements Dirigible{

	private String calle;
	private int num;
	private String ciudad;
	private String zipCode;

	public DirFra(String calle, int num, String ciudad, String zipCode) {
		this.calle = calle;
		this.num = num;
		this.ciudad = ciudad;
		this.zipCode = zipCode;
	}
	
	@Override
	public void calcularRuta() {
		System.out.println("Adressant � l'adresse:");
		System.out.println("\t" + num + ", Rue du " + calle);
		System.out.println("\t" + "Ville: " + ciudad );
		System.out.println("\t"+ "Code Postal: " + zipCode);
	}

	@Override
	public String toString() {
		return "DirFra [calle=" + calle + ", num=" + num + ", ciudad=" + ciudad + ", zipCode=" + zipCode + "]";
	}
	
	

}
