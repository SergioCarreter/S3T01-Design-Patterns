package n2ex1;

public class FabricaDir  implements FabricaAbs {

	@Override
	public Dirigible getDir(Paises pais, String calle, int num, String ciudad, String zipCode) {
		
		Dirigible dir=null;
		switch(pais) {
			case SPA:
				dir = new DirSpa(calle, num, ciudad, zipCode);
				break;
			case FRA:
				dir = new DirFra(calle, num, ciudad, zipCode);
				break;
			case UK:
				dir = new DirUK(calle, num, ciudad, zipCode);
				break;
			default:
				System.out.println("Pais no registrado");
		}
		return dir;
	}

	@Override
	public Llamable getTel(Paises pais, int num) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
