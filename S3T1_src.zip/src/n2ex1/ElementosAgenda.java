package n2ex1;

public enum ElementosAgenda {
	
	TEL, DIR;

}
