package n2ex1;

public class GeneraFabrica {

	public static FabricaAbs getFactory( ElementosAgenda ele ) {
		
		FabricaAbs fab= null;
		
		if ( ele == ElementosAgenda.TEL ) {
			fab = new FabricaTel();
		} else if ( ele == ElementosAgenda.DIR ) {
			fab = new FabricaDir();
		}
		
		return fab;
		
	}

}
