package n2ex1;

public class DirSpa implements Dirigible {
	
	private String calle;
	private int num;
	private String ciudad;
	private String zipCode;

	public DirSpa(String calle, int num, String ciudad, String zipCode) {
		this.calle = calle;
		this.num = num;
		this.ciudad = ciudad;
		this.zipCode = zipCode;
	}
	
	@Override
	public void calcularRuta() {
		System.out.println("Dirigiendose a la direccion:");
		System.out.println( "	Calle: " + calle + ", " + num );
		System.out.println("	Ciudad: " + ciudad );
		System.out.println("	Codigo Postal: " + zipCode);
	}

	@Override
	public String toString() {
		return "DirSpa [calle=" + calle + ", num=" + num + ", ciudad=" + ciudad + ", zipCode=" + zipCode + "]";
	}
	
	

}
