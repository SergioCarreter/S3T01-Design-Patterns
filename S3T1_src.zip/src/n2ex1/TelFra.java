package n2ex1;

public class TelFra implements Llamable{

	private static final String PREFIJO = "+33";
	private int numero;

	public TelFra(int numero) {
		this.numero = numero;
	}
	
	@Override
	public void llamar() {
		System.out.println( "Apellant le numero: " + PREFIJO + numero);
	}

	@Override
	public String toString() {
		return "TelFra [numero=" + PREFIJO + numero + "]";
	}
	
	

}
